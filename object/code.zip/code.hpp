#ifndef __CODE__
#define __CODE__

#include <stdio.h>

void* code_open(char* path, char** start, char** end) {
	// this function will interac with file
	printf("open %s\n", path);
	return NULL;
}

#endif /*__CODE__*/